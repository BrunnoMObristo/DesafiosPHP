<?php

$nome = "Samus"
$sobrenome = "Aran"


echo "A caçadora de recompensas ", $nome, $sobrenome, " parte novamente para outro planeta em busca do Metroid sequestrado.", '<br>';

echo "No japão, seu nome seria lido como ", $sobrenome, $nome, '<br>';


?>
