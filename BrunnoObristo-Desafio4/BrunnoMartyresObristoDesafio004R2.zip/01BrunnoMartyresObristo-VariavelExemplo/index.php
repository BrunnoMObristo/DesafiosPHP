<?php
$nome = 'Samus Aran';
$idade = 21;
$altura = 1.90;
$comArmadura = true;

echo 'Zero Mission', '<br>';
echo 'Nome: ', $nome, '<br>';
echo 'Idade: ', $idade, '<br>';
echo 'Altura: ', $altura, '<br>';
echo 'Utilizando armadura: ', $comArmadura;
    
?>

 
<?php
//$animal1 = 'Cão de Guarda';
//$animal2 = &$animal1;

//echo 'Animal 1: ', $animal1, '<br>';
//echo 'Animal 2: ', $animal2, '<br>';

//$animal2 = 'Galo de briga';

//echo 'Animal 1: ', $animal1, '<br>';
//echo 'Animal 2: ', $animal2, '<br>';
?>

