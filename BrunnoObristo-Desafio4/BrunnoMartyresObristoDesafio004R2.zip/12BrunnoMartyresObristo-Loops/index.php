<?php  

$i = 1;
while ($i <= 10) {
    echo "Número gerado com While: ", $i++, "</br>"; 
}

for ($c = 11; $c <= 20; $c++) {
    echo "Número gerado com For:", $c, "</br>";
}

?>