<?php $a = array(
    "one" => 1,
    "two" => 2,
    "three" => 3,
    "seventeen" => 17
);

foreach ($a as $k => $v) {
    echo "Chave: ", $k, " Valor => $v.\n";
}

?>