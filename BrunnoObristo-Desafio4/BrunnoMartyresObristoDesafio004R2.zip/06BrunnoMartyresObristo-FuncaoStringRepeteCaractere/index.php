
<?php
$armadura = 'Varia Suit';
strlen($armadura);
$armadura = str_repeat("t", 99);
echo 'Qual armadura está usando? ', $armadura, '<br>';
strlen($armadura);


?>